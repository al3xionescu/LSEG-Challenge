
import unittest
from datetime import datetime
from log_monitor import parse_time, process_logs

class TestLogMonitor(unittest.TestCase):
    def test_parse_time(self):
        self.assertEqual(parse_time("12:34:56"), datetime.strptime("12:34:56", "%H:%M:%S"))

    def test_process_logs(self):
        entries = [
            {'timestamp': parse_time("12:00:00"), 'desc': "Task A", 'status': "START", 'pid': "123"},
            {'timestamp': parse_time("12:10:01"), 'desc': "Task A", 'status': "END", 'pid': "123"},
        ]
        report = process_logs(entries)
        self.assertEqual(len(report), 1)
        self.assertEqual(report[0]['level'], "ERROR")

if __name__ == '__main__':
    unittest.main()
