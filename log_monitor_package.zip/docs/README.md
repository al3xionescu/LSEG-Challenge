
# Log Monitor

## Overview
This tool parses log files to measure task durations and classify them based on thresholds:
- INFO: duration <= 5 minutes
- WARNING: 5 < duration <= 10 minutes
- ERROR: duration > 10 minutes

## Usage
Place a `logs.log` file with CSV rows formatted as:
```
HH:MM:SS,Description,START|END,PID
```
Then run:
```bash
python log_monitor.py
```

## Testing
Run tests with:
```bash
python -m unittest discover tests
```
