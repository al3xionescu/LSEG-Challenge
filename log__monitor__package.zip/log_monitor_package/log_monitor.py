import csv
from datetime import datetime, timedelta
from collections import defaultdict

# Thresholds in seconds
WARNING_THRESHOLD = 5 * 60
ERROR_THRESHOLD = 10 * 60

# Helper function to parse time
def parse_time(ts_str):
    return datetime.strptime(ts_str, "%H:%M:%S")

# Read and parse logs
def parse_log_file(filepath):
    log_entries = []
    with open(filepath, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if len(row) != 4:
                continue  # Skip malformed rows
            timestamp, desc, status, pid = row
            log_entries.append({
                'timestamp': parse_time(timestamp.strip()),
                'desc': desc.strip(),
                'status': status.strip(),
                'pid': pid.strip()
            })
    return log_entries

# Process log entries
def process_logs(log_entries):
    tasks = defaultdict(dict)  # pid -> {START: time, END: time, desc: description}
    report = []

    for entry in log_entries:
        pid = entry['pid']
        status = entry['status']
        if status == 'START':
            tasks[pid]['start'] = entry['timestamp']
            tasks[pid]['desc'] = entry['desc']
        elif status == 'END':
            tasks[pid]['end'] = entry['timestamp']

    for pid, info in tasks.items():
        if 'start' in info and 'end' in info:
            duration = (info['end'] - info['start']).total_seconds()
            level = "INFO"
            if duration > ERROR_THRESHOLD:
                level = "ERROR"
            elif duration > WARNING_THRESHOLD:
                level = "WARNING"

            report.append({
                'level': level,
                'pid': pid,
                'desc': info['desc'],
                'duration_sec': duration,
                'duration_str': str(timedelta(seconds=int(duration)))
            })

    return sorted(report, key=lambda x: x['duration_sec'], reverse=True)

# Print report
def print_report(report):
    for entry in report:
        print(f"[{entry['level']}] PID {entry['pid']} ({entry['desc']}) ran for {entry['duration_str']} ({entry['duration_sec']}s)")

if __name__ == "__main__":
    log_entries = parse_log_file("logs.log")
    report = process_logs(log_entries)
    print_report(report)